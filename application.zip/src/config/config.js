module.exports = {
    host: "localhost",
    username: "root",
    password: "mysql", 
    dialect:  "mysql",
    database: "db_cms_api",
    secret: "1C3C7E1694F1E9DAD939399E87E5FFB5DF06B2327CA31B409CB3",

  

}